class BaseUrl {
  static String url = "https://api.uzbekbazar.exadot.io";
}